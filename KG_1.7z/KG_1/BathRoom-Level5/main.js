///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, cmnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 5, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, MemoryCheckLevel2_choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline,  quesMarkMc, MemoryCheckLevel2_questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0,puzzle_cycle,timeOver_Status=0;//for db //q
var isBgSound = true;
var isEffSound = true;

var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////

var choiceArr = [];
var choiceArr1 = [];

var quesArr=[];
var posArr = []
var qno = [];
var pos = []
var btnx = [130, -70, -70, 245, 327, 365, 320, 350, 385, 400, 360, 640, 640, 523, 845, 860, 990, 430, 750, 445];
var btny = [95,  370, 185, 350, 65,  65,  140, 140,  140, 65, 230, 140, 380, 220, 190, 385, 330, 140, 170, 65];
var PosX = [130, -70, -70, 245, 327, 365, 320, 350, 385, 400, 360, 640, 640, 523, 845, 860, 990, 430, 750, 445];
var PosY = [95,  370, 185, 350, 65,  65,  140, 140,  140, 65, 230, 140, 380, 220, 190, 385, 330, 140, 170, 65];


var btnPadding = 50;
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var question;
var optiontext=[];
var cno = []
var qtype = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]

//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}

///////////////////////////////////////////////////////////////////
//////////////////////Changes for multiple starts /////////////////////////////

function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);
    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);

    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "BathRoom-Level5/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
          
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "question", src: gameAssetsPath + "question.png" },                    
            { id: "questionText1", src:  questionTextPath + "BathRoom-Level5-QT1.png" },
            { id: "questionText2", src:  questionTextPath + "BathRoom-Level5-QT2.png" },
            { id: "questionText3", src:  questionTextPath + "BathRoom-Level5-QT3.png" }       
        )
        preloadAllAssets()
        stage.update();
    }
}
//====================================================//
function doneLoading1(event) {
    loaderBar.visible = false;
    stage.update();
    var event = assets[i];
    var id = event.item.id;
    console.log("get Id =" + id)
     
    if (id == "questionText1") {

		questionText1 = new createjs.Bitmap(preload.getResult('questionText1'));
		container.parent.addChild(questionText1);
		questionText1.visible = false;
    }
  
    if (id == "questionText2") {

		questionText2 = new createjs.Bitmap(preload.getResult('questionText2'));
		container.parent.addChild(questionText2);
		questionText2.visible = false;
    }
  
    if (id == "questionText3") {

		questionText3 = new createjs.Bitmap(preload.getResult('questionText3'));
		container.parent.addChild(questionText3);
		questionText3.visible = false;
    }
  
    if (id == "choice1") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 60,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 0, "height": 303, "count": 0, "regY": 0, "width": 404 }
        });
        choice1 = new createjs.Sprite(spriteSheet1);
        choice1.visible = false;
        container.parent.addChild(choice1);
    }

    if (id == "question") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 60,
            "images": [preload.getResult("question")],
            "frames": { "regX": 0, "height": 303, "count": 0, "regY": 0, "width": 404 }
        });
        question= new createjs.Sprite(spriteSheet1);
        question.visible = false;
        container.parent.addChild(question);
    }

  
   }

function tick(e) {
    stage.update();
}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////


function handleClick(e) {
    qno=between(0,19)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }   
}

function CreateGameElements() {

    interval = setInterval(countTime, 1000);
    container.parent.addChild(questionText1);
    questionText1.visible = false;
    questionText1.x = 0; questionText1.y = 0;

    container.parent.addChild(questionText2);
    questionText2.visible = false;
    questionText2.x = 0; questionText2.y =0;

    container.parent.addChild(questionText3);
    questionText3.visible = false;
    questionText3.x = 0; questionText3.y =0; 
  
    for (i = 0; i < 20; i++) {      
        quesArr[i] = question.clone();
        container.parent.addChild(quesArr[i]);
        quesArr[i].visible = false;
        quesArr[i].x=PosX[i];
        quesArr[i].y=PosY[i];
        quesArr[i].scaleX=quesArr[i].scaleY=1

    }


    for (i = 0; i < 6; i++) { 
        choiceArr[i] = choice1.clone();
        container.parent.addChild(choiceArr[i]);
        choiceArr[i].visible = false;
        choiceArr[i].scaleX=choiceArr[i].scaleY=1

    }


  if (isQuestionAllVariations) 
  {
      qtype = [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1];
      posArr =[0,1,2,3,4,5,0,1,2,3,0,1,2,3,4,5,0,1,2,3];   
  } 
  else 
  {
      qtype = [1,2,1,2,1,2,1,2,1,2];
      posArr=[0,1,2,3,4,5,0,1,2,3];
      qtype.sort(randomSort)
      posArr.sort(randomSort)
  }
}

function helpDisable() {
    for (i = 0; i < 6; i++) {
        choiceArr[i].mouseEnabled = false;
 
    }

}

function helpEnable() {
    for (i = 0; i < 6; i++) {
        choiceArr[i].mouseEnabled = true;

    }
}
//==================================================pickques===============================================================================//
function pickques() {   

    pauseTimer();
    //for db
    tx = 0;
    qscnt++;
    //db
    cnt++;
    quesCnt++;

    panelVisibleFn(); 
    currentObj = []
    pos = [];
   
    for (i = 0; i < 20; i++) {      
            cno[i] =i
        }
        cno.sort(randomSort)
        console.log("cno" + cno)

      
   //////////////////////Changes for multiple end/////////////////////////////
   questionText1.visible=false;
   questionText2.visible=false;
   questionText3.visible=false;

   for (i = 0; i < 20; i++) {
      
    quesArr[i].visible = false;
    quesArr[i].alpha=0
	
      quesArr[i].x=PosX[cno[i]];
      quesArr[i].y=PosY[cno[i]];
    quesArr[i].gotoAndStop(cno[i])
     
   
   }
    createTween();

}
function createTween() {
    questionText1.visible = true;
    questionText1.alpha = 0;
    createjs.Tween.get(questionText1).wait(100)
    .to({ alpha: 1 }, 500)
   
  setTimeout(showQuestion,500)
}
function showQuestion()
{ 
   ////////////////////////////////////////////////
   for (i = 0; i < 5; i++) {
    quesArr[i].visible = true;
    quesArr[i].alpha = 1;

     quesArr[i].x=PosX[cno[i]];
     quesArr[i].y=PosY[cno[i]];
    

    createjs.Tween.get(quesArr[i])   
}


/////////////////////////////////////////////

 clearquesInterval = setInterval(createChoices, 5000);
}
function createChoices() {
    console.log("createChoices")
    clearInterval(clearquesInterval)
    clearquesInterval = 0;
     questionText1.visible=false;
     for (i = 0; i < 5; i++) {
        quesArr[i].visible = false;
     }
  
 /////////////////////////////////////////////////Show Question///////////////////////////////////////////////////


 for (i = 0; i < 6; i++) {
    choiceArr[i].visible = false;
    choiceArr[i].x = btnx[cno[i]];
    choiceArr[i].y = btny[cno[i]];
    choiceArr[i].name=i
   }
    if(qtype[cnt]==1)
   {   
  
      questionText2.visible=false;

      for (i = 0; i < 6; i++) {     
        choiceArr[i].gotoAndStop(cno[i+6]);
       }
      choiceArr[0].gotoAndStop(cno[0]);  
      ans=0; 
   }
    else{
     
        questionText3.visible=false; 
  
    for (i = 0; i <6; i++) {     
        choiceArr[i].gotoAndStop(cno[i]);
       }
       choiceArr[5].gotoAndStop(cno[6]);    
       ans=5;  
       }
    if (posArr[cnt] == 0) 
    {
        pos.push(0, 1,2,3,4,5);
    }
    else if (posArr[cnt] ==1) 
    {
        pos.push(3,2,5,4,1,0);
    }  
    else if (posArr[cnt] == 2) 
    {
        pos.push(1,2,4,0,5,3);
    }  
    else if (posArr[cnt] == 3)  
    {
        pos.push(1,5,4,0,2,3);
    }
    else if (posArr[cnt] == 4) 
    {
        pos.push(4,3,2,5,0,1);  
    }    
    else if (posArr[cnt] ==5) 
    {
        pos.push(4,3,2,5,0,1);  
    }
    for (i = 0; i < 6; i++) {
        choiceArr[pos[i]].x =btnx[cno[i]];
        choiceArr[pos[i]].y =btny[cno[i]];
        choiceArr[i].gotoAndStop(cno[i]);
    }
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    enablechoices();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}
function enablechoices() {
    console.log("enable");
    questionText1.visible=false;
    for (i = 0; i < 6; i++) {
        choiceArr[i].name =  i;
        choiceArr[i].visible = false;
		choiceArr[i].x = btnx[cno[i]]
		choiceArr[i].y = btny[cno[i]]
    }
    createTween1();
}
function createTween1() {
    createjs.Tween.removeAllTweens();
    console.log("Tween");
    if(qtype[cnt]==1)
    {
      questionText2.visible = true;
      questionText2.alpha = 0;
      createjs.Tween.get(questionText2).wait(100)
    .to({alpha:1 }, 500, createjs.Ease.bounceOut)

    }
    else{
    
        questionText3.visible = true;
        questionText3.alpha = 0;
        createjs.Tween.get(questionText3).wait(100)
        .to({alpha:1 }, 500, createjs.Ease.bounceOut)
        console.log("enter qt3")
    }
   setTimeout( showChoice,500);
}
function showChoice()
{
      createjs.Tween.removeAllTweens();
    for (i = 0; i < 6; i++) {        
        
      
           ///////////////////////////////////////////
        choiceArr[i].visible = true;
        choiceArr[i].alpha=1;

            createjs.Tween.get(choiceArr[pos[i]])
        .to({x:choiceArr[pos[i]].x-10,y:choiceArr[pos[i]].y+10}, 250)
        .to({x:choiceArr[pos[i]].x,y:choiceArr[pos[i]].y}, 250)
        .to({x:choiceArr[pos[i]].x+10,y:choiceArr[pos[i]].y+10}, 250) 
        .to({x:choiceArr[pos[i]].x,y:choiceArr[pos[i]].y}, 250)
    
         ///////////////////////////////////////////

    }

    repTimeClearInterval = setTimeout(AddListenerFn, 1000)
}
function AddListenerFn() {
    createjs.Tween.removeAllTweens();

    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")
    for (i = 0; i < 6; i++) {
       
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].cursor = "pointer";
        
        choiceArr[i].name =  i;
        choiceArr[i].visible = true;
        choiceArr[i].mouseEnabled = true;
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
function disablechoices() {
  
    for (i = 0; i < 6; i++) {
        choiceArr[i].visible=false;       
      
        choiceArr[i].alpha = 0
        choiceArr[i].removeEventListener("click", answerSelected);
        choiceArr[i].cursor = "default";
    
    }
    questionText1.visible=false;
   questionText2.visible=false;
   questionText3.visible=false;

   for (i = 0; i < 5; i++) {
    quesArr[i].visible = false;
   }

 
}

function answerSelected(e) {
   
    e.preventDefault();
    gameResponseTimerStop();
    uans = e.currentTarget.name;
    e.currentTarget.removeEventListener(answerSelected);
    if (ans == uans) {
        currentX = e.currentTarget.x + 85
        currentY = e.currentTarget.y +90
        disableMouse()
        for (i = 0; i < 6; i++) {
          
            choiceArr[i].removeEventListener("click", answerSelected);
           
        }
        
        setTimeout(correct, 500)
    } else {
        getValidation("wrong");
        disablechoices();
    }

}

function correct() {
    getValidation("correct");
    disablechoices();
}


function disableMouse() {
    for (i = 0; i < 5; i++) {
        choiceArr[i].mouseEnabled = false
    }
}

function enableMouse() {

}
