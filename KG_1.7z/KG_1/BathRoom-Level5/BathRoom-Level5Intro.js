var introTitle, introQuestxt, introQues, introArrow, introfingure,introArrMc;
var introQuesX = 425, introQuesY = 215;
var highlightTweenArr = []
var introMcArr1=[];
var introqhHolderMc;
var introArrMc=[]
var setIntroCnt = 0
var removeIntraval = 0
var introArrowX = 210, introArrowY = 50;
var introfingureX = 270, introfingureY = 200;


var posX12=[130, -70,-70,245,327 ]
var posY12=[95,370,185, 350,65]
var posX11 = [130, 320,350,385,400,360 ]
var posY11 = [95,140,140, 140,65,230 ]
var introArr = []
var introArr1 = []

function commongameintro() {
    introTitle = Title.clone();   
    introArrow = arrow1.clone();
    introfingure = fingure.clone();
    introQuestxt = questionText1.clone();
    introQuestxt1 = questionText2.clone();

    container.parent.addChild(introTitle)
    introTitle.visible = true;

    for (i = 0; i <5; i++) {
    
      
        introArr[i] = question.clone();
        container.parent.addChild(introArr[i]);
        introArr[i].visible = false;
        introArr[i].gotoAndStop(i);
        introArr[i].x =posX12[i];
        introArr[i].y = posY12[i];
      
    }

    for (i = 0; i < 6; i++) {

        introArr1[i] = choice1.clone();
        container.parent.addChild(introArr1[i]);
        introArr1[i].visible = false; 
        introArr1[i].gotoAndStop(i+5);
        introArr1[i].x = posX11[i]
        introArr1[i].y =  posY11[i]
   
    }
    introArr1[0].gotoAndStop(0);

   
 
    container.parent.addChild(introQuestxt);
    introQuestxt.visible = false;
    container.parent.addChild(introQuestxt1);
    introQuestxt1.visible = false;
 
    introQuestxt1.x = 0
    introQuestxt1.y = 0
 
 


    introQuestxt.visible = true;
    introQuestxt.alpha = 0;
    createjs.Tween.get(introQuestxt).to({ alpha: 1 }, 1000).call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        quesTween()
    }
}
function quesTween() {
  
 
     /////////////////////////////////////////////////////////
  for(i=0;i<5;i++)
  {
    introArr[i].visible = true;
    introArr[i].alpha=1;

        createjs.Tween.get(introArr[i])   
    .to({ x: introArr[i].x-10, y: introArr[i].y+10 }, 250)
    .to({ x: introArr[i].x, y: introArr[i].y },250)
    .to({ x: introArr[i].x+10, y: introArr[i].y+10 }, 250)
    .to({ x: introArr[i].x, y: introArr[i].y },250).wait(5000).call(handleComplete2_1)
 
  }

    
}

function handleComplete2_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        introRemember()
    
    }
}
function introRemember() {
   

  
   for (i = 0; i < 5; i++) {
        introArr[i].visible = false;
    }
    introQuestxt.visible = false; 
    introQuestxt1.visible = true;
setTimeout(handleComplete3_1,500)
}
function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        choiceTween()
       
    }
}
function choiceTween() {

      for (i = 0; i < 6; i++) {

        introArr1[i].visible = true;
        introArr1[i].alpha=1;
    
            createjs.Tween.get(introArr1[i])
        .to({x:introArr1[i].x-10,y:introArr1[i].y+10}, 250)
        .to({x:introArr1[i].x,y:introArr1[i].y}, 250)
        .to({x:introArr1[i].x+10,y:introArr1[i].y+10}, 250)
        .to({x:introArr1[i].x,y:introArr1[i].y}, 250).wait(500).call(handleComplete6_1);
     
         
    }

   

  
}
function handleComplete6_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        introCh1()
    }
}
function introCh1() {

    createjs.Tween.get(introArr1[0]).wait(600).to({ alpha: 1, scaleX: .95, scaleY:.95}, 500)
        .to({ scaleX:.85, scaleY: .85 }, 500).to({ scaleX: .95, scaleY:.95}, 500)
        .to({ scaleX: .85, scaleY:.85}, 700)
        .wait(2000).call(handleComplete7_1);
}
function handleComplete7_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        console.log("handleComplete1_5  == stopValue")
        removeGameIntro()

    }
    else {
        setArrowTween()
    }
}
function setArrowTween() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow);

        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).wait(400).call(this.onComplete1)

    }

}

function setFingureTween() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        container.parent.addChild(startBtn)
        container.parent.addChild(StartBtnMc)
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
        .to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350)
        .to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350).wait(200).call(this.onComplete2)

    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();

    // // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[1]) {
        container.parent.removeChild(highlightTweenArr[1]);
    }
    // // }
    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        setTimeout(setCallDelay, 500)
    }


}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    removeGameIntro()
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    console.log("removeGameIntro")
    createjs.Tween.removeAllTweens();
 

    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
    container.parent.removeChild(introQuestxt)
    introQuestxt.visible = false

    container.parent.removeChild(introQuestxt1)
    introQuestxt1.visible = false


    for (i = 0; i < 5; i++) {
        container.parent.removeChild(introArr[i]);
        introArr[i].visible = false;
        

    }


    for (i = 0; i < 6; i++) {
        container.parent.removeChild(introArr1[i]);
        introArr1[i].visible = false;
    
    }
    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }



}