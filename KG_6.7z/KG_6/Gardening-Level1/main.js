///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, cmnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 5, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, MemoryCheckLevel2_choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, quesMarkMc, MemoryCheckLevel2_questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q
var isBgSound = true;
var isEffSound = true;

var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var tween


var quesMc
var qHolderMc;
var cluetext;
var cluetextMc;
var choiceArr = [];
var choiceArr1 = [];
var choiceMcArr = []
var posArr = []
var qno = [];
var pos = []
var quesArr = ["Butterfly", "Horse", "Cow", "Goat", "Octopus", "StarFish", "Crab", "Seahorse", "EarthWorm", "Grasshopper", "Dragonfly", "Snake", "Rabbit",
    "Bear", "Beetle", "Fox", "Dog", "Giraffe", "Elephant", "Tiger", "Fish", "Tortoise"];

var btnx = [150, 790];
var btny = [220, 220];

var btnPadding = 50;
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var question;
var optiontext = [];
var cno = []
var qtype = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]

//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}

///////////////////////////////////////////////////////////////////
//////////////////////Changes for multiple starts /////////////////////////////

function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);
    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);

    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "Gardening-Level1/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(

            { id: "choice1", src: gameAssetsPath + "question.png" },
            { id: "question", src: gameAssetsPath + "question.png" },
            { id: "questionText1", src: questionTextPath + "Gardening-Level1-QT1.png" },
            { id: "questionText2", src: questionTextPath + "Gardening-Level1-QT2.png" },
            { id: "questionText3", src: questionTextPath + "Gardening-Level1-QT3.png" }


        )
        preloadAllAssets()
        stage.update();
    }
}
//====================================================//
function doneLoading1(event) {

    loaderBar.visible = false;
    stage.update();
    var event = assets[i];
    var id = event.item.id;
    console.log("get Id =" + id)


    if (id == "questionText1") {

        questionText1 = new createjs.Bitmap(preload.getResult('questionText1'));
        container.parent.addChild(questionText1);
        questionText1.visible = false;
    }
    if (id == "questionText2") {

        questionText2 = new createjs.Bitmap(preload.getResult('questionText2'));
        container.parent.addChild(questionText2);
        questionText2.visible = false;
    }
    if (id == "questionText3") {

        questionText3 = new createjs.Bitmap(preload.getResult('questionText3'));
        container.parent.addChild(questionText3);
        questionText3.visible = false;
    }


    if (id == "choice1") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 60,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 0, "height": 433, "count": 0, "regY": 0, "width": 340 }
        });
        choice1 = new createjs.Sprite(spriteSheet1);
        choice1.visible = false;
        container.parent.addChild(choice1);
    }

    if (id == "question") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 60,
            "images": [preload.getResult("question")],
            "frames": { "regX": 0, "height": 433, "count": 0, "regY": 0, "width": 340 }
        });
        question = new createjs.Sprite(spriteSheet1);
        question.visible = false;
        container.parent.addChild(question);
    }



}

function tick(e) {
    stage.update();
}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////


function handleClick(e) {
    qno = between(0, 21)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }
}

function CreateGameElements() {

    interval = setInterval(countTime, 1000);
    container.parent.addChild(questionText1);
    questionText1.visible = false;
    questionText1.x = 0; questionText1.y = 0;

    container.parent.addChild(questionText2);
    questionText2.visible = false;
    questionText2.x = 0; questionText2.y = 0;

    container.parent.addChild(questionText3);
    questionText3.visible = false;
    questionText3.x = 0; questionText3.y = 0;


    container.parent.addChild(question);
    question.visible = false;
    question.x = 470;
    question.y = 220;


    for (i = 0; i < 2; i++) {
        choiceMcArr[i] = new createjs.MovieClip()
        container.parent.addChild(choiceMcArr[i])
        choiceMcArr[i].regX = choiceMcArr[i].regY = 0;
        choiceArr[i] = choice1.clone();

        container.parent.addChild(choiceArr[i]);
        choiceArr[i].visible = false;
        choiceArr[i].scaleX = choiceArr[i].scaleY = 1
        choiceMcArr[i].addChild(choiceArr[i])
        choiceArr[i].x = btnx[i];
        choiceArr[i].y = btny[i]


    }


    if (isQuestionAllVariations) {
        qtype = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2]
        posArr = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1]

    }
    else {
        qtype = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2];
        posArr = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
        qtype.sort(randomSort)
        posArr.sort(randomSort)
    }
}

function helpDisable() {
    for (i = 0; i < 2; i++) {
        choiceArr[i].mouseEnabled = false;
        optiontext[i].mouseEnabled = false
    }

}

function helpEnable() {
    for (i = 0; i < 2; i++) {
        choiceArr[i].mouseEnabled = true;
        optiontext[i].mouseEnabled = true;
    }
}
//==================================================pickques===============================================================================//
function pickques() {

    pauseTimer();
    //for db
    tx = 0;
    qscnt++;
    //db
    cnt++;
    quesCnt++;
    console.log(qtype[cnt] + "=qtype==")
    panelVisibleFn();
    currentObj = []
    pos = [];

    for (i = 0; i < 22; i++) {

        cno[i] = i
    }
    cno.sort(randomSort)

    var rand = cno.indexOf(qno[cnt])
    console.log("cno///" + cno)
    cno.splice(rand, 1)
    console.log("cno" + cno)


    //////////////////////Changes for multiple end/////////////////////////////
    questionText1.visible = false;
    questionText2.visible = false;
    questionText3.visible = false;
    question.visible = false;
    question.gotoAndStop(qno[cnt]);

    createTween();

}
function createTween() {
    questionText1.visible = true;
    questionText1.alpha = 0;
    createjs.Tween.get(questionText1).wait(100)
        .to({ alpha: 1 }, 500)

    setTimeout(showQuestion, 500)
}
function showQuestion() {
    ////////////////////////////////////////////////
    question.visible = true;
    question.alpha = 1;

    createjs.Tween.get(question)
        .to({ x: question.x - 10, y: question.y + 10 }, 250)
        .to({ x: question.x + 10, y: question.y + 10 }, 250)
        .to({ y: question.y }, 250)
        .to({ x: question.x }, 250)

    /////////////////////////////////////////////

    clearquesInterval = setInterval(createChoices, 3000);
}
function createChoices() {
    console.log("createChoices")
    clearInterval(clearquesInterval)
    clearquesInterval = 0;
    questionText1.visible = false;
    question.visible = false;

    /////////////////////////////////////////////////Show Question///////////////////////////////////////////////////


    for (i = 0; i < 2; i++) {
        choiceArr[i].visible = false;
        choiceArr[i].x = btnx[i];
        choiceArr[i].y = btny[i]
        choiceArr[i].name = i
    }




    if (posArr[cnt] == 0) {
        questionText2.visible = false
        choiceArr[0].gotoAndStop(qno[cnt]);
        choiceArr[1].gotoAndStop(cno[0]);

        pos.push(1, 0);


    } else if (posArr[cnt] == 1) {
        questionText3.visible = false
        choiceArr[1].gotoAndStop(qno[cnt]);
        choiceArr[0].gotoAndStop(cno[0]);

        pos.push(0, 1);

    }
    ans = 0
    for (i = 0; i < 2; i++) {
        switch (i) {
            case 0: choiceArr[pos[i]].x = 150


                break;

            case 1: choiceArr[pos[i]].x = 790

                break;


        }

        choiceArr[pos[i]].y = 220
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    enablechoices();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}
function enablechoices() {
    console.log("enable");
    for (i = 0; i < 2; i++) {
        choiceArr[i].name = i;
        choiceArr[i].visible = false;

    }
    createTween1();
}
function createTween1() {
    createjs.Tween.removeAllTweens();
    console.log("Tween");
    ////////////////////////////////////////////////////////////////

    if (posArr[cnt] == 0) {
        questionText2.visible = true;
        questionText2.alpha = 0;
        createjs.Tween.get(questionText2).wait(100)
            .to({ alpha: 1 }, 500, createjs.Ease.bounceOut)

    }
    else if (posArr[cnt] == 1) {
        questionText3.visible = true;
        questionText3.alpha = 0;
        createjs.Tween.get(questionText3).wait(100)
            .to({ alpha: 1 }, 500, createjs.Ease.bounceOut)
        console.log("enter qt3")
    }

    for (i = 0; i < 2; i++) {


        ///////////////////////////////////////////
        choiceArr[pos[i]].visible = true;
        choiceArr[pos[i]].alpha = 0;

        createjs.Tween.get(choiceArr[pos[i]]).wait(500)
            .to({ alpha: 1 }, 500)

        ///////////////////////////////////////////

    }

    repTimeClearInterval = setTimeout(AddListenerFn, 2000)
}
function AddListenerFn() {
    createjs.Tween.removeAllTweens();

    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")
    for (i = 0; i < 2; i++) {

        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].cursor = "pointer";

        choiceArr[i].name = i;
        choiceArr[i].visible = true;
        choiceArr[i].mouseEnabled = true;
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
function disablechoices() {

    for (i = 0; i < 2; i++) {
        choiceArr[i].visible = false;
        choiceArr[i].alpha = 1
        choiceArr[i].removeEventListener("click", answerSelected);
        choiceArr[i].cursor = "default";

    }
    questionText1.visible = false;
    questionText2.visible = false;
    questionText3.visible = false;
    question.visible = false;



}

function answerSelected(e) {

    e.preventDefault();
    gameResponseTimerStop();
    uans = e.currentTarget.name;
    e.currentTarget.removeEventListener(answerSelected);
    if (ans == uans) {
        currentX = e.currentTarget.x + 85
        currentY = e.currentTarget.y + 90
        disableMouse()
        for (i = 0; i < 2; i++) {

            choiceArr[i].removeEventListener("click", answerSelected);

        }

        setTimeout(correct, 500)
    } else {
        getValidation("wrong");
        disablechoices();
    }

}

function correct() {
    getValidation("correct");
    disablechoices();
}


function disableMouse() {
    for (i = 0; i < 2; i++) {
        choiceArr[i].mouseEnabled = false
    }
}

function enableMouse() {

}
//===========================================================================================//
