
///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 3, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg;
var qscnt = -1;
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;
var isBgSound = true;
var isEffSound = true;
var currentX, currentY
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var rand;
var chNo;
var cno=[]
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];

var chpos = [];
var choiceArr = []
var wrngchoiceArr1 = []
var wrngchoiceArr2 = []
var posArr = [0, 1, 2, 1, 0, 0]
var attemptCnt
var ansMc = []
var posx = [];
var posy = [];
var xAxis = [260,580, 900]
var yAxis =[550,550,550]

var crtchoiceArr = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
var wrngchoiceArr1 = [15,7,16,0,5,11,14,12,1,6,13,17,2,8,10,4,3]
var wrngchoiceArr2 = [4,0,11,5,15,8,9,13,6,7,10,14,3,17,12,1,2]
//register key functions

///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////

function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    createLoader()
    createCanvasResize()


    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "HouseHoldShapes-Level2/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "questionText", src: questionTextPath + "HouseHoldShapes-Level2-QT.png" },
            { id: "question", src: gameAssetsPath + "question.png" },
            { id: "choice1", src: gameAssetsPath + "choiceImages1.png" }
          //  { id: "qhHolder", src: gameAssetsPath + "Holder.png" }

        )
        preloadAllAssets()
        stage.update();
    }
}
//=================================================================DONE LOADING=================================================================//
function doneLoading1(event) {

    loaderBar.visible = false;
    stage.update();
    var event = assets[i];
    var id = event.item.id;

    if (id == "questionText") {

        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }
    // if (id == "qhHolder") {

        // qhHolder = new createjs.Bitmap(preload.getResult('qhHolder'));
        // container.parent.addChild(qhHolder);
        // qhHolder.visible = false;
    // }

    if (id == "choice1") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 237, "count": 0, "regY": 50, "width": 245 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice1 = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(choice1);
        choice1.visible = false;

    }

    if (id == "question") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 197, "count": 0, "regY": 50, "width": 234 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        question = new createjs.Sprite(spriteSheet1);
        question.visible = false;
        container.parent.addChild(question);
    };


}

function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======HANDLE CLICK========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(0, 17);
    qno.splice(qno.indexOf(0), 1);
    qno.push(0);
    CreateGameStart();
    if (gameType == 0) {
        CreateGameElements();
        getStartQuestion();
    }
    else {
        //for db
        getdomainpath();
        //end
    }

}
////////////////////////////////////////////////////////////=======CREATION OF GAME ELEMENTS========///////////////////////////////////////////////////////////////////
function CreateGameElements() {

    interval = setInterval(countTime, 1000);
    container.parent.addChild(questionText);
    questionText.visible = false;
    // container.parent.addChild(qhHolder);
    // qhHolder.visible = false;
    question.visible = false;
    container.parent.addChild(question)
    question.x = 540; question.y = 200
      for (i = 0; i < choiceCnt; i++) {
        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])
        choiceArr[i].visible = false;
        choiceArr[i].x = xAxis[i]
        choiceArr[i].y = 470;
        choiceArr[i].name = i
        choiceArr[i].scaleX = choiceArr[i].scaleY = 1
        posx = choiceArr[i].x;
        posy = choiceArr[i].y;
        chpos.push({ posx: choiceArr[i].x, posy: choiceArr[i].y });
        console.log(";;;;;;;;;;;;;;;" + choiceArr[i].x)
    }  
	
	
	/* for (i = 0; i < 3; i++) {

        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])
        choiceArr[i].visible = false; 
		 choiceArr[i].x = xAxis[i]
        choiceArr[i].y = 470;
        choiceArr[i].name = i
        choiceArr[i].scaleX = choiceArr[i].scaleY = .8;
         posx = choiceArr[i].x;
        posy = choiceArr[i].y;
		chpos.push({ posx: choiceArr[i].x, posy: choiceArr[i].y });
        choiceArr[i].gotoAndStop(i);
    } 
	 
	
	
	*/
	
	

    if (isQuestionAllVariations) {
        posArr = [0,1,2,0,1,2,0,1,2,0,0,1,2,1]
        posArr.sort(randomSort)
    } else {
        posArr = [0,1,2,0,1,2,0,1,2,0]
        posArr.sort(randomSort)
    }
}
//==============================================================HELP ENABLE/DISABLE===================================================================//
function helpDisable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}
function helpEnable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}
//==================================================================PICKQUES==========================================================================//
function pickques() {
    pauseTimer();
    tx = 0;
    cnt++;
    quesCnt++;
    qscnt++;
    attemptCnt = 0;
    currentObj = [];
    panelVisibleFn();
    pos = [];
    question.gotoAndStop(qno[cnt]);
    question.visible = false;
    console.log("qno///" + qno[cnt])


    for (i = 0; i < 18; i++) {
      
        cno[i] =i
    }    
	cno.sort(randomSort) 
    console.log("cno///" + cno)
     var rand = cno.indexOf(qno[cnt])
     
     cno.splice(rand, 1)
     console.log("cno" + cno)
	
	

        if(qno[cnt]<10)
    {
        
  cno=between(0,8)
  cno.sort(randomSort) 
    console.log("cno///" + cno)
     var rand = cno.indexOf(qno[cnt])
     
     cno.splice(rand, 1)
     console.log("cno" + cno)

    }
    else  if(qno[cnt]>=9||qno[cnt]<18){
        cno=between(9,17)
        cno.sort(randomSort) 
        var rand = cno.indexOf(qno[cnt])
   
     cno.splice(rand, 1)
     console.log("cno" + cno)
    
    }    
 for(i=0;i<choiceCnt;i++)
 {
    choiceArr[i].gotoAndStop(cno[i]);
    //choiceArr[i].gotoAndStop(cno[qno[cnt]]);
	 console.log("cnee" + qno[cnt])
 }
     choiceArr[0].gotoAndStop(qno[cnt]);

    if (posArr[cnt] == 0) {
        pos.push(0, 1,2) 
    } else if(posArr[cnt]==1)
    {
        pos.push(1, 2,0) 
    }
    else { 
        pos.push(2,0,1)
    }
     for (i = 0; i < choiceCnt; i++) {
       // choiceArr[i].x = posx[cno[i]]
       // choiceArr[i].y = posy[cno[i]]
		 choiceArr[i].x = chpos[pos[i]].posx;
         choiceArr[i].y = chpos[pos[i]].posy;
    } 
	
	/* if (posArr[cnt] == 0) {
        questionText2.visible = false
        choiceArr[0].gotoAndStop(qno[cnt]);
        choiceArr[1].gotoAndStop(cno[0]);

        pos.push(0, 1, 2);
        wrngchoiceArr1[0].x = xAxis[qno[cnt]]
        wrngchoiceArr1[0].y = yAxis[qno[cnt]]
        wrngchoiceArr1[1].x = xAxis[cno[0]]
        wrngchoiceArr1[1].y = yAxis[cno[0]]

    } 

	for (i = 1; i <= choiceCnt; i++) {
        switch (i) {
            case 1: choiceArr[chpos[pos[i - 1]]].x = 260;
                break;
            case 2: choiceArr[chpos[pos[i - 1]]].x = 580;
                break;
            case 3: choiceArr[chpos[pos[i - 1]]].x = 900;
                break;
        }
        choiceArr[chpos[pos[i - 1]]].y = 550;
    } */
	
	 
	
    ans = 0;
    createTween();


    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}
//====================================================================CHOICE ENABLE/DISABLE==============================================================//


function createTween() {
    questionText.visible = true;
    questionText.alpha = 0;
    questionText.y = -500
    createjs.Tween.get(questionText).wait(200)
        .to({ y: 0, alpha: 1 });

    // qhHolder.visible = true;
    // qhHolder.alpha = 0;
    // qhHolder.y = -500
    // createjs.Tween.get(qhHolder).wait(200)
        // .to({ y: 0, alpha: 1 });

    question.x = 575; question.y = 200;
    question.visible = false;
    question.alpha = 0
    question.scaleX = question.scaleY = -1.2;
    createjs.Tween.get(question).wait(500)
        .to({ visible: true, y: 230, scaleX: 1, scaleY: 1, alpha: 1 }, 500) 
	

    var tempval = 1000
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[pos[i]].visible = true;
        choiceArr[pos[i]].alpha = 0;
        choiceArr[i].scaleX = choiceArr[i].scaleY = .8
        choiceArr[i].y = 468
        createjs.Tween.get(choiceArr[pos[i]]).wait(tempval)
            .to({ visible: true, x: xAxis[i],y:yAxis[i], alpha: 1 }, 500)
    }
    repTimeClearInterval = setTimeout(AddListenerFn, 2000)
}

function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true
        choiceArr[i].visible = true;
        choiceArr[i].cursor = "pointer"
        choiceArr[i].alpha = 1;
        choiceArr[i].id = i
        choiceArr[i].name = i
        choiceArr[i].addEventListener("click", answerSelected)
          }
 

    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}


function disablechoices() {
    createjs.Tween.removeAllTweens();
   // qhHolder.visible = false;
    questionText.visible = false
    question.visible = false;
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].visible = false;
        choiceArr[i].removeEventListener("click", answerSelected)
   
    }
}
//=================================================================ANSWER SELECTION=======================================================================//
function answerSelected(e) {
    e.preventDefault();
    gameResponseTimerStop();
    uans = e.currentTarget.name;
    if (ans == uans) {
       
      
        for (i = 0; i < choiceCnt; i++) {
            choiceArr[i].mouseEnabled = false
            choiceArr[i].removeEventListener("click", answerSelected)
        }

        setTimeout(correct, 500)
    } else {
        getValidation("wrong");
        disablechoices();
    }
}

function correct() {
    getValidation("correct");
    disablechoices();
}
