var introTitle, introQuestxt, introQues, introArrow, introfingure;
var introQuesX = 425, introQuesY = 215;
var highlightTweenArr = []
var introMcArr1 = [];
var introqhHolderMc;
var introArrMc = []
var setIntroCnt = 0
var removeIntraval = 0
var introArrowX = 925, introArrowY = 190;
var introfingureX = 1000, introfingureY = 450;
var posX11 = [850, 210]
var posY11 = [270, 270]

var posY12 = [230]

var introArr = []
var introArr1 = []


function commongameintro() {
    introTitle = Title.clone();
    introArrow = arrow1.clone()
    introfingure = fingure.clone()
    introQuestxt = questionText1.clone();
    introQuestxt1 = questionText2.clone();

    container.parent.addChild(introTitle)
    introTitle.visible = true;

    for (i = 0; i < 1; i++) {

        introArrMc[i] = new createjs.MovieClip()
        container.parent.addChild(introArrMc[i])
        introArrMc[i].regX = introArrMc.regY = 0;
        introArrMc[i].visible = false;

        introArr[i] = question.clone();
        container.parent.addChild(introArr[i]);
        introArr[i].visible = false;
        introArr[i].scaleX = introArr[i].scaleY = 1
        introArr[i].gotoAndStop(i);
        introArr[i].x = 470
        introArr[i].y = posY12[i]
        introArrMc[i].addChild(introArr[i])
    }

    for (i = 0; i < 2; i++) {
        introMcArr1[i] = new createjs.MovieClip()
        container.parent.addChild(introMcArr1[i])
        introMcArr1[i].regX = introMcArr1[i].regY = 0;
        introMcArr1[i].visible = false;


        introArr1[i] = choice1.clone();
        container.parent.addChild(introArr1[i]);
        introArr1[i].visible = false;
        introArr1[i].regX = introArr1[i].regY = 50;
        introArr1[i].gotoAndStop(i + 2);
        introArr1[i].x = posX11[i]
        introArr1[i].y = posY11[i]
        introMcArr1[i].addChild(introArr1[i])
    }
    introArr1[0].gotoAndStop(0);



    container.parent.addChild(introQuestxt);
    introQuestxt.visible = false;
    container.parent.addChild(introQuestxt1);
    introQuestxt1.visible = false;

    introQuestxt1.x = 0
    introQuestxt1.y = 0




    introQuestxt.visible = true;
    introQuestxt.alpha = 0;
    createjs.Tween.get(introQuestxt).to({ alpha: 1 }, 1000).call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        quesTween()
    }
}
function quesTween() {


    /////////////////////////////////////////////////////////

    introArr[0].visible = true;
    introArr[0].alpha = 1;

    introArrMc = new createjs.MovieClip()
    container.parent.addChild(introArrMc)
    introArrMc.regX = introArrMc.regY = 0;
    introArrMc.visible = true;
    introArrMc.addChild(introArr[0])
    introArrMc.timeline.addTween(createjs.Tween.get(introArr[0])
        .to({ x: introArr[0].x - 10 }, 39)
        .to({ x: introArr[0].x }, 40)
        .to({ x: introArr[0].x + 10 }, 39)
        .to({ x: introArr[0].x }, 40)
        .wait(1))
    setTimeout(handleComplete2_1, 5000);

}

function handleComplete2_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        introRemember()

    }
}
function introRemember() {


    for (i = 0; i < 1; i++) {
        introArr[i].visible = false;
    }
    introQuestxt.visible = false;
    introQuestxt1.visible = true;
    setTimeout(handleComplete3_1, 500)
}
function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        choiceTween()

    }
}
function choiceTween() {

    for (i = 0; i < 2; i++) {

        introArr1[i].visible = true;
        introArr1[i].alpha = 1;

        introMcArr1[i] = new createjs.MovieClip()
        container.parent.addChild(introMcArr1[i])
        introMcArr1[i].regX = introMcArr1[i].regY = 0;

        introMcArr1[i].addChild(introArr1[i])
        introMcArr1[i].timeline.addTween(createjs.Tween.get(introArr1[i])
            .to({ y: introArr1[i].y - 10 }, 20)
            .to({ y: introArr1[i].y }, 19)
            .to({ y: introArr1[i].y + 10 }, 20)
            .to({ y: introArr1[i].y }, 19)
            .wait(1))

    }
    setTimeout(handleComplete6_1, 2000);




}
function handleComplete6_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        introCh1()
    }
}
function introCh1() {

    createjs.Tween.get(introArr1[0]).wait(600).to({ alpha: 1, scaleX: .95, scaleY: .95 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 500).to({ scaleX: .95, scaleY: .95 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 700)
        .wait(2000).call(handleComplete7_1);
}
function handleComplete7_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        console.log("handleComplete1_5  == stopValue")
        removeGameIntro()

    }
    else {
        setArrowTween()
    }
}
function setArrowTween() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow);

        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).wait(400).call(this.onComplete1)

    }

}

function setFingureTween() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        container.parent.addChild(startBtn)
        container.parent.addChild(StartBtnMc)
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350).wait(200).call(this.onComplete2)

    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();

    // // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[1]) {
        container.parent.removeChild(highlightTweenArr[1]);
    }
    // // }
    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        setTimeout(setCallDelay, 500)
    }


}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    removeGameIntro()
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    console.log("removeGameIntro")
    createjs.Tween.removeAllTweens();


    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
    container.parent.removeChild(introQuestxt)
    introQuestxt.visible = false

    container.parent.removeChild(introQuestxt1)
    introQuestxt1.visible = false

    container.parent.removeChild(introArrMc)
    introArrMc.visible = false;

    for (i = 0; i < 1; i++) {
        container.parent.removeChild(introArr[i]);
        introArr[i].visible = false;
    }


    for (i = 0; i < 2; i++) {
        container.parent.removeChild(introArr1[i]);
        introArr1[i].visible = false;
    }
    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }



}