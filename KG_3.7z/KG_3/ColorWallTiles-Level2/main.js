

///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////

var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 2, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg;
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;
var qscnt = -1
var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;
var px = [100, 320, 540, 760, 980]
var py = [295, 295, 295, 295, 490, 490]
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var currentX, currentY

///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var chpos = [];
var choiceArr = []
var posArr = []
var quesMcArr1 = [];
var AnswerImage = [];
//register key functions

///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////

function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */
    assetsPath = "assets/";
    gameAssetsPath = "ColorWallTiles-Level2/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "questionText1", src: questionTextPath + "ColorWallTiles-Level2-QT.png" },
            { id: "question", src: gameAssetsPath + "question.png" },
            { id: "Answer", src: gameAssetsPath + "Answer.png" },
            { id: "choice1", src: gameAssetsPath + "choiceImages1.png" },
            { id: "choice2", src: gameAssetsPath + "choiceImages2.png" },
            { id: "qHolder", src: gameAssetsPath + "Holder.png" }

        )

        preloadAllAssets()
        stage.update();
    }

}
//=================================================================DONE LOADING=================================================================//

function doneLoading1(event) {
    loaderBar.visible = false;
    stage.update();
    var event = assets[i];
    var id = event.item.id;
    if (id == "questionText1") {
        questionText1 = new createjs.Bitmap(preload.getResult('questionText1'));
        container.parent.addChild(questionText1);
        questionText1.visible = false;
    }

    if (id == "qHolder") {
        qHolder = new createjs.Bitmap(preload.getResult('qHolder'));
        container.parent.addChild(qHolder);
        qHolder.visible = false;
    }

    if (id == "choice1") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 170, "count": 0, "regY": 50, "width": 169 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice1 = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(choice1);
        choice1.visible = false;

    }

    if (id == "choice2") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice2")],
            "frames": { "regX": 50, "height": 169, "count": 0, "regY": 50, "width": 169 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice2 = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(choice2);
        choice2.visible = false;

    }


    if (id == "question") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 290, "count": 0, "regY": 50, "width": 594 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        question = new createjs.Sprite(spriteSheet1);
        question.visible = false;
        container.parent.addChild(question);
    };
    if (id == "Answer") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("Answer")],
            "frames": { "regX": 50, "height": 290, "count": 0, "regY": 50, "width": 594 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        Answer = new createjs.Sprite(spriteSheet1);
        Answer.visible = false;
        container.parent.addChild(Answer);

    };

}

function tick(e) {
    stage.update();
}

/////////////////////////////////////////////////////////////////=======HANDLE CLICK========///////////////////////////////////////////////////////////////////

function handleClick(e) {
    qno = between(0, 19);
    qno.splice(qno.indexOf(0), 1)
    qno.push(0)
    console.log("qno" + qno)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////=======CREATION OF GAME ELEMENTS========///////////////////////////////////////////////////////////////////
function CreateGameElements() {
    interval = setInterval(countTime, 1000);

    container.parent.addChild(questionText1);
    questionText1.visible = false;
    questionText1.x = 0;

    container.parent.addChild(qHolder);
    qHolder.visible = false;

    container.parent.addChild(choice1, choice2, choice3);
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i] = this["choice" + (i + 1)].clone();
        container.parent.addChild(choiceArr[i]);
        choiceArr[i].visible = false;
        choiceArr[i].cursor = "pointer";
    }

    //
    question.visible = false;
    container.parent.addChild(question);
    question.x = 393; question.y = 257;

    Answer.visible = false;
    container.parent.addChild(Answer);
    Answer.x = 393; Answer.y = 257;
    
    if (isQuestionAllVariations) {
        createGameWiseQuestions()
        posArr = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1]

    } else {
        posArr = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1]

    }

    posArr.sort(randomSort)
}
//==============================================================HELP ENABLE/DISABLE===================================================================//
function helpDisable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}
function helpEnable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}
//=================================================================================================================================//

function pickques() {

    pauseTimer();
    tx = 0;
    cnt++;
    quesCnt++;
    qscnt++;
    chpos = [];
    attemptCnt = 0;
    currentObj = [];
    panelVisibleFn();

    //=================================================================================================================================//

    console.log("qnoooo" + qno)

    question.visible = false
    question.gotoAndStop(qno[cnt]);

    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].visible = false;
        choiceArr[i].gotoAndStop(qno[cnt])
        choiceArr[i].name = "ch" + i
    }

    if (posArr[cnt] == 0) {
        chpos.push(0, 1);
    }
    else {
        chpos.push(1, 0);
    }


    for (i = 0; i < choiceCnt; i++) {
        switch (i) {
            case 0: choiceArr[chpos[i]].x = 197
                break;

            case 1: choiceArr[chpos[i]].x = 1000
                break;
        }
        choiceArr[chpos[i]].y = 565
    }

    ans = "ch0";
    createTween();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}

function createTween() {

    questionText1.visible = true;
    questionText1.alpha = 0;
    createjs.Tween.get(questionText1).wait(100)
        .to({ visible: true, alpha: 1 }, 300);

    qHolder.visible = true;
    qHolder.alpha = 0;
    createjs.Tween.get(qHolder).wait(200)
        .to({ alpha: 1 }, 500);

    question.visible = true;
    question.alpha = 0;
    question.x = -280;
    createjs.Tween.get(question).wait(500)
        .to({ x: 393, alpha: 1 }, 500, createjs.Ease.bounceOut);


    ///////////////////////////choice tween////////////////////////////////////

    for (i = 0; i < choiceCnt; i++) {
        choiceArr[chpos[i]].visible = true;
        choiceArr[chpos[i]].alpha = 0;

        if (i == 1) {
            createjs.Tween.get(choiceArr[chpos[i]]).wait(1000)
                .to({ scaleX: .95, scaleY: .95, alpha: 1 }, 250)
                .to({ scaleX: 1, scaleY: 1, alpha: 1 }, 250)
        }
        else {
            createjs.Tween.get(choiceArr[chpos[i]]).wait(1000)
                .to({ scaleX: .95, scaleY: .95, alpha: 1 }, 250)
                .to({ scaleX: 1, scaleY: 1, alpha: 1 }, 250)
        }
    }

    repTimeClearInterval1 = setTimeout(AddListenerFn, 3000)

}

function AddListenerFn() {
    clearTimeout(repTimeClearInterval1)

    console.log("eventlisterneer")

    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].mouseEnabled = true
        choiceArr[i].cursor = "pointer";
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()

}



function disablechoices() {
    createjs.Tween.removeAllTweens();
    questionText1.visible = false;
    Answer.visible = false;
    question.visible = false;
    qHolder.visible = false;

    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].visible = false;
        choiceArr[i].mouseEnabled = false;
        choiceArr[i].cursor = "pointer";
        choiceArr[i].alpha = 1
        choiceArr[i].removeEventListener("click", answerSelected);
    }
}

function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    gameResponseTimerStop();
    console.log(ans + " =correct= " + uans)
    if (ans == uans) {
        e.currentTarget.removeEventListener("click", answerSelected)
        for (i = 0; i < choiceCnt; i++) {
            choiceArr[i].mouseEnabled = false;
        }
        question.visible = false;
        Answer.visible = true;
        Answer.gotoAndStop(qno[cnt]);
        setTimeout(correctFn, 1000)

    }
    else {
        for (i = 0; i < choiceCnt; i++) {
            choiceArr[i].visible = false;
            choiceArr[i].mouseEnabled = false;
        }
        getValidation("wrong");
        disablechoices();
    }

}
function correctFn() {
    getValidation("correct");
    disablechoices();
}



